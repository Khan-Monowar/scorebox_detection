# scorebox_detection_high > 2022-09-28 5:20pm
https://universe.roboflow.com/object-detection/scorebox_detection_high

Provided by Roboflow
License: CC BY 4.0

